const config = {
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "postgres", //Update this parameter
    database: "blog", //Update this parameter
    connection_limit:100
}

export default config;