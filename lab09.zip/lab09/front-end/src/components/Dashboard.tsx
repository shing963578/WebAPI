import React from "react";
const Dashboard = () => {
    return <p>Dashboard</p>;
}

export default Dashboard;