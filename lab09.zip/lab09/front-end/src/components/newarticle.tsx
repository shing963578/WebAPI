import React from "react";
import {Form, Input , Button } from "antd";
import { api } from "../common/http-common" ;
import axios from "axios"
import { Base64 } from "js-base64"

const { TextArea } = Input;

const NewArticle = () => {
    const handleFormSubmit = (values:any) => {
        const title = values.title;
        const allText = values.context;
        const authorID = 1
        console.log(values, title, allText, authorID );
        const url = api.uri + "/articles"
        const username = "alice"
        const password = "alice"
        const access_token = Base64.encode(`${username}:${password}`)
        axios.post(url, {
            "title":title,
            "allText":allText,
            "authorID": 1
        }, {
            headers:{
                'Authorization' : `Basic ${access_token}`
            }
        })
        .then((res)=> {
           if(res.status === 201){
            console.log("successfully create Articles!")
           }else{
            console.log("Failed create articles....")
           }
        })
    }
    const contentRules =[{ required: true, message: "Please input the data"}]
    return (
        <Form name = 'article' onFinish={(values) => handleFormSubmit(values)}>
            <Form.Item name="title" label="Title" rules={contentRules}>
                <Input/>
            </Form.Item>
            <Form.Item name="context" label="Context" rules={contentRules}>
                <TextArea rows={4} />
            </Form.Item>
            <Form.Item name="submitBtn" >
                <Button type="primary" htmlType="submit">Submit</Button>
            </Form.Item>
        </Form>
    )
}
export default NewArticle