import React from "react";
const Error404 = () => {
    return (
        <div>
        <h1>404 - Page not Find</h1>
        </div>
    );
}
export default Error404;