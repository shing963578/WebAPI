export const api = {
    uri: "http://localhost:10888/api/v1"
}